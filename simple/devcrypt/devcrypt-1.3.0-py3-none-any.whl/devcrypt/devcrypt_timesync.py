"""
devcrypt_timesync.py
Time-Synchronized Token Module for DevCrypt
"""

import time
import hmac
import hashlib
import struct
from typing import Optional, Tuple, Dict, Any
from dataclasses import dataclass

# Import from your existing devcrypt
from devcrypt import DevCrypt, CryptoConfig, DecryptionError


@dataclass
class TimeSyncConfig:
    """Configuration for time-synchronized tokens"""
    interval: int = 1
    tolerance: int = 1
    seed_length: int = 32
    use_devanagari: bool = True


class TimeSynchronizedToken:
    """Time-Synchronized Rotating Token Generator"""
    
    def __init__(self, shared_seed: str, config: Optional[TimeSyncConfig] = None):
        self.config = config or TimeSyncConfig()
        self.shared_seed = shared_seed.encode('utf-8')
        
        self.devanagari_map = {
            '0': '०', '1': '१', '2': '२', '3': '३', '4': '४',
            '5': '५', '6': '६', '7': '७', '8': '८', '9': '९',
            'a': 'अ', 'b': 'ब', 'c': 'च', 'd': 'द', 'e': 'ए',
            'f': 'फ', 'g': 'ग', 'h': 'ह', 'i': 'इ', 'j': 'ज',
            'k': 'क', 'l': 'ल', 'm': 'म', 'n': 'न', 'o': 'ओ',
            'p': 'प', 'q': 'क़', 'r': 'र', 's': 'स', 't': 'त',
            'u': 'उ', 'v': 'व', 'w': 'व्', 'x': 'क्ष', 'y': 'य',
            'z': 'ज़'
        }
    
    def _get_time_counter(self, timestamp: Optional[float] = None) -> int:
        ts = timestamp if timestamp is not None else time.time()
        return int(ts // self.config.interval)
    
    def _generate_raw_token(self, counter: int) -> bytes:
        counter_bytes = struct.pack('>Q', counter)
        return hmac.new(self.shared_seed, counter_bytes, hashlib.sha256).digest()
    
    def _enhance_with_devanagari(self, hex_token: str) -> str:
        if not self.config.use_devanagari:
            return hex_token
        
        enhanced = ""
        for i, char in enumerate(hex_token):
            if i % 2 == 0 and char.lower() in self.devanagari_map:
                enhanced += self.devanagari_map[char.lower()]
            else:
                enhanced += char
        return enhanced
    
    def generate_current_token(self, length: int = 32) -> str:
        counter = self._get_time_counter()
        raw_token = self._generate_raw_token(counter)
        hex_token = raw_token.hex()[:length]
        return self._enhance_with_devanagari(hex_token)
    
    def generate_token_at_time(self, timestamp: float, length: int = 32) -> str:
        counter = self._get_time_counter(timestamp)
        raw_token = self._generate_raw_token(counter)
        hex_token = raw_token.hex()[:length]
        return self._enhance_with_devanagari(hex_token)
    
    def validate_token(self, token: str, length: int = 32) -> Tuple[bool, int]:
        current_counter = self._get_time_counter()
        
        for offset in range(-self.config.tolerance, self.config.tolerance + 1):
            check_counter = current_counter + offset
            expected = self._enhance_with_devanagari(
                self._generate_raw_token(check_counter).hex()[:length]
            )
            if hmac.compare_digest(token, expected):
                return True, offset
        return False, 0
    
    def get_token_info(self) -> Dict[str, Any]:
        current_time = time.time()
        counter = self._get_time_counter()
        next_rotation = (counter + 1) * self.config.interval
        
        return {
            "current_counter": counter,
            "current_token": self.generate_current_token(),
            "seconds_until_rotation": round(next_rotation - current_time, 2),
            "interval": self.config.interval,
            "tolerance": self.config.tolerance
        }


class DevCryptTimeSynced:
    """DevCrypt wrapper with time-synchronized token rotation"""
    
    def __init__(self, shared_seed: str, config: Optional[CryptoConfig] = None,
                 time_config: Optional[TimeSyncConfig] = None):
        self.dc = DevCrypt(config)
        self.time_token = TimeSynchronizedToken(shared_seed, time_config)
    
    def encrypt(self, plaintext: str, user_password: str,
                metadata: Optional[Dict[str, Any]] = None) -> Tuple[str, Dict[str, Any]]:
        """Encrypt with current rotating token"""
        current_token = self.time_token.generate_current_token()
        token_info = self.time_token.get_token_info()
        
        combined_secret = self.dc._combine_factors(user_password, current_token)
        
        full_metadata = metadata or {}
        full_metadata["time_counter"] = token_info["current_counter"]
        full_metadata["encrypted_at"] = time.time()
        
        encrypted_data = self.dc.encrypt(plaintext, combined_secret, full_metadata)
        
        return encrypted_data, {
            "counter": token_info["current_counter"],
            "valid_until": time.time() + self.time_token.config.interval
        }
    
    def decrypt(self, encrypted_data: str, user_password: str,
                encryption_counter: Optional[int] = None) -> Tuple[str, Dict[str, Any]]:
        """Decrypt with time-synchronized token"""
        
        if encryption_counter is not None:
            timestamp = encryption_counter * self.time_token.config.interval
            token = self.time_token.generate_token_at_time(timestamp)
            combined_secret = self.dc._combine_factors(user_password, token)
            return self.dc.decrypt(encrypted_data, combined_secret)
        
        current_counter = self.time_token._get_time_counter()
        tolerance = self.time_token.config.tolerance
        
        for offset in range(-tolerance, tolerance + 1):
            try:
                counter = current_counter + offset
                timestamp = counter * self.time_token.config.interval
                token = self.time_token.generate_token_at_time(timestamp)
                combined_secret = self.dc._combine_factors(user_password, token)
                return self.dc.decrypt(encrypted_data, combined_secret)
            except Exception:
                continue
        
        raise DecryptionError("Token window expired. Provide encryption_counter.")
    
    def get_current_token_info(self) -> Dict[str, Any]:
        """Get current rotating token information"""
        return self.time_token.get_token_info()