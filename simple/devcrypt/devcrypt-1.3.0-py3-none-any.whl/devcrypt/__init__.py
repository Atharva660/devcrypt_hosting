# devcrypt/__init__.py

from .core import (
    DevCrypt,
    CryptoConfig,
    CryptoMode,
    SecurityLevel,
    DevCryptError,
    AuthenticationError,
    DecryptionError,
    ConfigurationError,
    TokenValidationError,
    encrypt,
    decrypt
)

from .devcrypt_timesync import (
    TimeSyncConfig,
    TimeSynchronizedToken,
    DevCryptTimeSynced
)

__version__ = "1.3.0"

__all__ = [
    # Core
    "DevCrypt",
    "CryptoConfig", 
    "CryptoMode",
    "SecurityLevel",
    # Errors
    "DevCryptError",
    "AuthenticationError",
    "DecryptionError",
    "ConfigurationError",
    "TokenValidationError",
    # Functions
    "encrypt",
    "decrypt",
    # Time Sync (NEW)
    "TimeSyncConfig",
    "TimeSynchronizedToken",
    "DevCryptTimeSynced"
]