import base64
import os
import secrets
import string
import time
import threading
from typing import Union, Tuple, Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum
import json
import logging
import math

from Crypto.Cipher import AES, ChaCha20_Poly1305
from Crypto.Hash import HMAC, SHA256, SHA3_256, BLAKE2b
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
from argon2.low_level import hash_secret_raw, Type
from argon2 import PasswordHasher


class CryptoMode(Enum):
    """Supported encryption modes"""
    AES_GCM = "aes_gcm"
    AES_CBC_HMAC = "aes_cbc_hmac"
    CHACHA20_POLY1305 = "chacha20_poly1305"


class SecurityLevel(Enum):
    """Security levels with different parameters"""
    FAST = "fast"         # Lower security, faster performance
    BALANCED = "balanced" # Good balance (default)
    PARANOID = "paranoid" # Maximum security, slower performance


@dataclass
class CryptoConfig:
    """Configuration for crypto operations"""
    mode: CryptoMode = CryptoMode.AES_GCM
    security_level: SecurityLevel = SecurityLevel.BALANCED
    key_rotation_interval: int = 7776000  # 90 days in seconds
    max_data_size: int = 100 * 1024 * 1024  # 100MB limit
    mandatory_devanagari: bool = True  # Force Devanagari characters in tokens
    min_devanagari_ratio: float = 0.20# Minimum 30% Devanagari characters
    
    def get_argon2_params(self) -> Dict[str, int]:
        """Get Argon2 parameters based on security level"""
        params = {
            SecurityLevel.FAST: {
                "time_cost": 2,
                "memory_cost": 32768,  # 32MB
                "parallelism": 1
            },
            SecurityLevel.BALANCED: {
                "time_cost": 3,
                "memory_cost": 65536,  # 64MB
                "parallelism": 1
            },
            SecurityLevel.PARANOID: {
                "time_cost": 4,
                "memory_cost": 131072,  # 128MB
                "parallelism": 2
            }
        }
        return params[self.security_level]


class DevCryptError(Exception):
    """Base exception for DevCrypt errors"""
    pass


class AuthenticationError(DevCryptError):
    """HMAC/Authentication verification failed"""
    pass


class DecryptionError(DevCryptError):
    """Decryption failed"""
    pass


class ConfigurationError(DevCryptError):
    """Invalid configuration"""
    pass


class TokenValidationError(DevCryptError):
    """Token validation failed"""
    pass


class DevCrypt:
    """
    DevCrypt - Modern, Unicode-ready encryption for Python with Mandatory Devanagari Support
    
    Features:
    - Multiple encryption modes (AES-GCM, AES-CBC+HMAC, ChaCha20-Poly1305)
    - Argon2 key derivation with configurable security levels
    - Dual-factor authentication (password + server token)
    - Mandatory Unicode support with Devanagari script token generation
    - Key rotation and versioning
    - Memory-safe operations
    - Thread-safe design
    - Enhanced security through mandatory multilingual tokens
    """
    
    VERSION = "1.2.0"
    MAGIC_BYTES = b"DEVCRYPT"
    
    # Enhanced Devanagari character sets for better security
    DEVANAGARI_SETS = {
        'vowels': "अआइईउऊऋऌऍएऐऑओऔ",
        'consonants': "कखगघङचछजझञटठडढणतथदधनपफबभमयरलळवशषसहक्षत्रज्ञ",
        'numerals': "०१२३४५६७८९",
        'special': "ॐ।॥ॽऽ्ँंःऻ",
        'matras': "ाािीुूृॄॅेैॉोौ्",
        'conjuncts': "क्षत्रज्ञश्रद्मप्रस्तक्तन्त",
        'modern': "ॲॳॴॵॶॷॸॹॺॻॼॽॾॿ"
    }
    
    def __init__(self, config: Optional[CryptoConfig] = None):
        self.config = config or CryptoConfig()
        self.salt_len = 32  # Increased from 16
        self.key_len = 32
        self._key_cache = {}  # Thread-safe key caching
        self._cache_lock = threading.Lock()
        
        # Initialize password hasher for server tokens
        self._ph = PasswordHasher(
            time_cost=2,
            memory_cost=32768,
            parallelism=1,
            hash_len=32,
            salt_len=16
        )
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        
        # Validate configuration
        if self.config.mandatory_devanagari and self.config.min_devanagari_ratio < 0.2:
            self.logger.warning("Minimum Devanagari ratio too low for security, setting to 0.30")
            self.config.min_devanagari_ratio = 0.30

    def _get_comprehensive_devanagari_chars(self) -> str:
        """Get comprehensive Devanagari character set for maximum security"""
        all_chars = ""
        for char_set in self.DEVANAGARI_SETS.values():
            all_chars += char_set
        
        # Remove duplicates while preserving order
        seen = set()
        unique_chars = ""
        for char in all_chars:
            if char not in seen:
                seen.add(char)
                unique_chars += char
        
        return unique_chars

    def generate_server_token(self, length: int = 32, include_timestamp: bool = True, 
                             include_devanagari: bool = None, devanagari_ratio: float = None) -> str:
        """
        Generate a cryptographically secure server token with MANDATORY Devanagari script
        
        Args:
            length: Token length (minimum 16)
            include_timestamp: Whether to include creation timestamp
            include_devanagari: DEPRECATED - Always True due to mandatory requirement
            devanagari_ratio: Ratio of Devanagari characters (minimum enforced by config)
        
        Returns:
            Secure random token with mixed character sets (always includes Devanagari)
        """
        MAX_RETRIES = 5
        
        if length < 16:
            raise ConfigurationError("Token length must be at least 16 characters")
        
        # FORCE Devanagari inclusion - override any parameters
        if devanagari_ratio is None or devanagari_ratio < self.config.min_devanagari_ratio:
            devanagari_ratio = self.config.min_devanagari_ratio
            
        # Ensure we have enough characters for proper distribution
        min_devanagari_chars = max(6, int(length * devanagari_ratio))
        min_ascii_chars = max(6, length - min_devanagari_chars)
        
        # Adjust if token is too short for proper distribution
        if min_devanagari_chars + min_ascii_chars > length:
            if length >= 20:
                min_devanagari_chars = max(6, length // 3)
                min_ascii_chars = length - min_devanagari_chars
            else:
                raise ConfigurationError(f"Token too short for secure Devanagari distribution (minimum 20 chars recommended)")
        
        # Get character sets
        ascii_chars = string.ascii_letters + string.digits + "!@#$%^&*()-_+={}[]|:;<>,.?/"
        devanagari_chars = self._get_comprehensive_devanagari_chars()
        
        if not devanagari_chars:
            raise ConfigurationError("Devanagari character set is empty - cannot generate secure token")
        
        # Retry logic with proper loop (NOT RECURSION)
        for retry_count in range(MAX_RETRIES):
            try:
                # Build token with guaranteed character distribution
                token_parts = []
                
                # First, ensure we have minimum required Devanagari characters
                devanagari_categories = [
                    self.DEVANAGARI_SETS['vowels'],
                    self.DEVANAGARI_SETS['consonants'], 
                    self.DEVANAGARI_SETS['numerals'],
                    self.DEVANAGARI_SETS['matras'],
                    self.DEVANAGARI_SETS['special']
                ]
                
                # Add guaranteed Devanagari characters from different categories
                for i in range(min_devanagari_chars):
                    if i < len(devanagari_categories):
                        category = devanagari_categories[i % len(devanagari_categories)]
                        if category:
                            token_parts.append(secrets.choice(category))
                        else:
                            token_parts.append(secrets.choice(devanagari_chars))
                    else:
                        token_parts.append(secrets.choice(devanagari_chars))
                
                # Add ASCII characters with category distribution
                ascii_categories = [
                    string.ascii_lowercase,
                    string.ascii_uppercase,
                    string.digits,
                    "!@#$%^&*()-_+={}[]|:;<>,.?/"
                ]
                
                for i in range(min_ascii_chars):
                    category = ascii_categories[i % len(ascii_categories)]
                    token_parts.append(secrets.choice(category))
                
                # Fill remaining positions if any
                remaining = length - len(token_parts)
                for i in range(remaining):
                    # Alternate between Devanagari and ASCII for remaining positions
                    if i % 2 == 0:
                        token_parts.append(secrets.choice(devanagari_chars))
                    else:
                        token_parts.append(secrets.choice(ascii_chars))
                
                # Shuffle the parts multiple times for better randomness
                for _ in range(5):  # Increased shuffling
                    secrets.SystemRandom().shuffle(token_parts)
                
                token = ''.join(token_parts)
                
                # CRITICAL: Validate the generated token
                if self._validate_token_security(token):
                    # Add timestamp if requested
                    if include_timestamp:
                        timestamp = int(time.time())
                        # Use Devanagari separator for enhanced uniqueness
                        separator = "।"
                        token += f"{separator}{timestamp}"
                    
                    return token
                else:
                    # Log warning for retry
                    if retry_count < MAX_RETRIES - 1:
                        self.logger.warning(
                            f"Token validation failed (attempt {retry_count + 1}/{MAX_RETRIES}), retrying..."
                        )
                        # Adjust parameters for next retry
                        devanagari_ratio = min(devanagari_ratio + 0.05, 0.6)  # Slightly increase ratio
                        min_devanagari_chars = max(6, int(length * devanagari_ratio))
                        min_ascii_chars = length - min_devanagari_chars
                        continue
                    else:
                        # Last attempt failed
                        raise TokenValidationError(
                            f"Failed to generate valid token after {MAX_RETRIES} attempts. "
                            f"Token validation too strict or configuration issue."
                        )
                        
            except Exception as e:
                if retry_count == MAX_RETRIES - 1:
                    raise TokenValidationError(f"Token generation failed: {e}")
                self.logger.warning(f"Token generation error on attempt {retry_count + 1}: {e}")
                continue
        
        # This should never be reached due to the loop logic above
        raise TokenValidationError(f"Unexpected error in token generation after {MAX_RETRIES} attempts")

    def _validate_token_security(self, token: str) -> bool:
        """
        Validate that token meets security requirements with relaxed validation
        
        Args:
            token: Token to validate
            
        Returns:
            True if token meets security requirements
        """
        if not token or len(token) < 16:
            return False
        
        # Remove timestamp part if present
        if "।" in token:
            token_part = token.split("।")[0]
        else:
            token_part = token
            
        # Count character types
        devanagari_count = 0
        ascii_count = 0
        
        for char in token_part:
            if '\u0900' <= char <= '\u097F':  # Devanagari Unicode range
                devanagari_count += 1
            elif char in (string.ascii_letters + string.digits + string.punctuation):
                ascii_count += 1
        
        total_count = len(token_part)
        devanagari_ratio = devanagari_count / total_count if total_count > 0 else 0
        
        # RELAXED validation for mandatory Devanagari
        if self.config.mandatory_devanagari:
            if devanagari_count < 4:  # Reduced from 6 to 4
                return False
            if devanagari_ratio < (self.config.min_devanagari_ratio * 0.8):  # 80% of required ratio
                return False
        
        # Check character diversity (relaxed)
        unique_chars = len(set(token_part))
        if unique_chars < max(6, total_count // 5):  # Reduced from 8 and 25% to 6 and 20%
            return False
        
        # Check for proper mixing (relaxed - allow longer runs)
        max_consecutive_same_type = 0
        current_consecutive = 1
        last_char_type = None
        
        for char in token_part:
            if '\u0900' <= char <= '\u097F':
                char_type = 'devanagari'
            else:
                char_type = 'ascii'
            
            if char_type == last_char_type:
                current_consecutive += 1
                max_consecutive_same_type = max(max_consecutive_same_type, current_consecutive)
            else:
                current_consecutive = 1
            
            last_char_type = char_type
        
        # Allow longer consecutive runs (increased from 5 to 8)
        if max_consecutive_same_type > 8:
            return False
            
        return True

    def generate_multilingual_token(self, length: int = 32, scripts: Optional[list] = None,
                                  enforce_devanagari: bool = None) -> str:
        """
        Generate a token using multiple scripts with MANDATORY Devanagari inclusion
        
        Args:
            length: Token length (minimum 16)
            scripts: List of scripts to include (Devanagari always included)
            enforce_devanagari: DEPRECATED - Always True due to mandatory requirement
        
        Returns:
            Secure random token with multiple scripts (always includes Devanagari)
        """
        if length < 16:
            raise ConfigurationError("Token length must be at least 16 characters")
        
        # Force Devanagari inclusion - NO EXCEPTIONS
        if scripts is None:
            scripts = ['devanagari', 'latin', 'arabic']
        elif 'devanagari' not in scripts:
            scripts.insert(0, 'devanagari')  # Put Devanagari first
        
        # Character sets for different scripts
        char_sets = {
            'latin': string.ascii_letters + string.digits + "!@#$%^&*()-_+=[]{}|;:,.<>?",
            'devanagari': self._get_comprehensive_devanagari_chars(),
            'arabic': "ابتثجحخدذرزسشصضطظعغفقكلمنهويىءآأؤإئ١٢٣٤٥٦٧٨٩٠",
            'cyrillic': "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя",
            'greek': "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψω",
            'hebrew': "אבגדהוזחטיכלמנסעפצקרשת",
            'chinese': "中文汉字国语普通话简体繁體龙凤呈祥福禄寿喜",
            'japanese': "ひらがなカタカナ漢字日本語あいうえおかきくけこさしすせそ",
            'korean': "한글한국어조선말가나다라마바사아자차카타파하",
            'thai': "กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮ",
            'bengali': "অআইঈউঊঋঌএঐওঔকখগঘঙচছজঝঞটঠডঢণতথদধনপফবভমযরলশষসহ"
        }
        
        # Validate scripts
        available_scripts = set(char_sets.keys())
        requested_scripts = set(scripts)
        invalid_scripts = requested_scripts - available_scripts
        
        if invalid_scripts:
            raise ConfigurationError(f"Unsupported scripts: {invalid_scripts}. Available: {available_scripts}")
        
        # Calculate distribution with Devanagari priority
        script_count = len(scripts)
        min_devanagari = max(6, int(length * self.config.min_devanagari_ratio))
        
        # Ensure Devanagari gets priority allocation
        remaining_length = length - min_devanagari
        other_scripts = [s for s in scripts if s != 'devanagari']
        
        if other_scripts:
            chars_per_other_script = remaining_length // len(other_scripts)
            extra_chars = remaining_length % len(other_scripts)
        else:
            chars_per_other_script = 0
            extra_chars = 0
        
        token_parts = []
        
        # First, add guaranteed Devanagari characters
        devanagari_chars = char_sets['devanagari']
        for _ in range(min_devanagari):
            token_parts.append(secrets.choice(devanagari_chars))
        
        # Then add other scripts
        for i, script in enumerate(other_scripts):
            char_count = chars_per_other_script
            if i < extra_chars:
                char_count += 1
            
            script_chars = char_sets[script]
            for _ in range(char_count):
                token_parts.append(secrets.choice(script_chars))
        
        # Shuffle multiple times for better randomness
        for _ in range(5):
            secrets.SystemRandom().shuffle(token_parts)
        
        token = ''.join(token_parts)
        
        # Validate the token
        if not self._validate_token_security(token):
            # Retry with adjusted parameters
            return self.generate_multilingual_token(length, scripts, True)
        
        return token

    def get_token_entropy(self, token: str) -> Dict[str, Any]:
        """
        Calculate the entropy and security metrics of a token with Devanagari awareness
        
        Args:
            token: Token to analyze
        
        Returns:
            Dictionary with entropy and security information including Devanagari analysis
        """
        if not token:
            return {"entropy": 0, "strength": "invalid", "devanagari_compliant": False}
        
        # Count unique characters
        unique_chars = set(token)
        charset_size = len(unique_chars)
        token_length = len(token)
        
        # Calculate theoretical maximum entropy
        max_entropy = token_length * math.log2(charset_size) if charset_size > 1 else 0
        
        # Calculate actual entropy (simplified)
        char_freq = {}
        for char in token:
            char_freq[char] = char_freq.get(char, 0) + 1
        
        actual_entropy = 0
        for count in char_freq.values():
            if count > 0:
                probability = count / token_length
                actual_entropy -= probability * math.log2(probability)
        
        actual_entropy *= token_length
        
        # Enhanced strength calculation considering Devanagari
        base_strength = ""
        if max_entropy >= 256:
            base_strength = "paranoid"
        elif max_entropy >= 128:
            base_strength = "strong"
        elif max_entropy >= 64:
            base_strength = "moderate"
        elif max_entropy >= 32:
            base_strength = "weak"
        else:
            base_strength = "very_weak"
        
        # Detect character scripts with enhanced detection
        scripts_detected = []
        devanagari_count = 0
        ascii_count = 0
        unicode_count = 0
        
        for char in token:
            if char in string.ascii_letters + string.digits + string.punctuation:
                if "latin" not in scripts_detected:
                    scripts_detected.append("latin")
                ascii_count += 1
            elif '\u0900' <= char <= '\u097F':  # Devanagari range
                if "devanagari" not in scripts_detected:
                    scripts_detected.append("devanagari")
                devanagari_count += 1
                unicode_count += 1
            elif '\u0600' <= char <= '\u06FF':  # Arabic range
                if "arabic" not in scripts_detected:
                    scripts_detected.append("arabic")
                unicode_count += 1
            elif '\u0400' <= char <= '\u04FF':  # Cyrillic range
                if "cyrillic" not in scripts_detected:
                    scripts_detected.append("cyrillic")
                unicode_count += 1
            elif '\u4E00' <= char <= '\u9FFF':  # Chinese range
                if "chinese" not in scripts_detected:
                    scripts_detected.append("chinese")
                unicode_count += 1
            elif '\u3040' <= char <= '\u309F' or '\u30A0' <= char <= '\u30FF':  # Japanese
                if "japanese" not in scripts_detected:
                    scripts_detected.append("japanese")
                unicode_count += 1
            elif '\uAC00' <= char <= '\uD7AF':  # Korean
                if "korean" not in scripts_detected:
                    scripts_detected.append("korean")
                unicode_count += 1
            else:
                unicode_count += 1
        
        # Check Devanagari compliance
        devanagari_ratio = devanagari_count / token_length if token_length > 0 else 0
        devanagari_compliant = (
            devanagari_count >= 6 and 
            devanagari_ratio >= self.config.min_devanagari_ratio
        )
        
        # Adjust strength based on multilingual content
        if len(scripts_detected) >= 3 and devanagari_compliant:
            strength_bonus = "_multilingual_enhanced"
        elif devanagari_compliant:
            strength_bonus = "_devanagari_enhanced"
        else:
            strength_bonus = "_standard"
        
        final_strength = base_strength + strength_bonus
        
        return {
            "token_length": token_length,
            "unique_characters": charset_size,
            "max_entropy_bits": round(max_entropy, 2),
            "actual_entropy_bits": round(actual_entropy, 2),
            "entropy_ratio": round(actual_entropy / max_entropy if max_entropy > 0 else 0, 3),
            "strength_level": final_strength,
            "scripts_detected": scripts_detected,
            "devanagari_count": devanagari_count,
            "devanagari_ratio": round(devanagari_ratio, 3),
            "devanagari_compliant": devanagari_compliant,
            "ascii_count": ascii_count,
            "unicode_count": unicode_count,
            "script_diversity": len(scripts_detected),
            "estimated_crack_time": self._estimate_crack_time(max_entropy),
            "unicode_aware": unicode_count > 0,
            "mandatory_requirements_met": devanagari_compliant and self.config.mandatory_devanagari
        }

    def _estimate_crack_time(self, entropy_bits: float) -> str:
        """
        Estimate time to crack based on entropy with enhanced calculations
        
        Args:
            entropy_bits: Entropy in bits
        
        Returns:
            Human-readable crack time estimate
        """
        if entropy_bits <= 0:
            return "instant"
        
        # Assume 1 billion attempts per second (modern hardware)
        # But account for Unicode processing overhead
        attempts_per_second = 5e8  # Reduced for Unicode complexity
        total_combinations = 2 ** entropy_bits
        average_time_seconds = total_combinations / (2 * attempts_per_second)
        
        if average_time_seconds < 1:
            return "less than 1 second"
        elif average_time_seconds < 60:
            return f"{int(average_time_seconds)} seconds"
        elif average_time_seconds < 3600:
            return f"{int(average_time_seconds / 60)} minutes"
        elif average_time_seconds < 86400:
            return f"{int(average_time_seconds / 3600)} hours"
        elif average_time_seconds < 31536000:
            return f"{int(average_time_seconds / 86400)} days"
        elif average_time_seconds < 31536000 * 1000:
            return f"{int(average_time_seconds / 31536000)} years"
        elif average_time_seconds < 31536000 * 1000000:
            return f"{int(average_time_seconds / (31536000 * 1000))} thousand years"
        elif average_time_seconds < 31536000 * 1000000000:
            return f"{int(average_time_seconds / (31536000 * 1000000))} million years"
        else:
            return "heat death of universe"

    def validate_token_format(self, token: str, strict: bool = True) -> Dict[str, Any]:
        """
        Validate token format and security compliance
        
        Args:
            token: Token to validate
            strict: Whether to enforce strict validation rules
            
        Returns:
            Validation results dictionary
        """
        results = {
            "valid": False,
            "errors": [],
            "warnings": [],
            "metrics": {}
        }
        
        try:
            if not token:
                results["errors"].append("Token is empty")
                return results
            
            # Get token metrics
            metrics = self.get_token_entropy(token)
            results["metrics"] = metrics
            
            # Check basic requirements
            if len(token) < 16:
                results["errors"].append("Token too short (minimum 16 characters)")
            
            # Check Devanagari compliance
            if self.config.mandatory_devanagari:
                if not metrics["devanagari_compliant"]:
                    results["errors"].append(
                        f"Token does not meet Devanagari requirements "
                        f"(found {metrics['devanagari_count']} chars, "
                        f"ratio {metrics['devanagari_ratio']:.3f}, "
                        f"required ratio {self.config.min_devanagari_ratio:.3f})"
                    )
            
            # Check entropy requirements
            if metrics["max_entropy_bits"] < 64:
                results["errors"].append("Token entropy too low (minimum 64 bits)")
            elif metrics["max_entropy_bits"] < 128:
                results["warnings"].append("Token entropy could be higher for better security")
            
            # Check character diversity
            if metrics["unique_characters"] < 8:
                results["errors"].append("Token lacks character diversity")
            
            # Strict validation
            if strict:
                if metrics["script_diversity"] < 2:
                    results["warnings"].append("Token could benefit from multiple scripts")
                
                if metrics["entropy_ratio"] < 0.8:
                    results["warnings"].append("Token has low entropy efficiency")
            
            # Determine overall validity
            results["valid"] = len(results["errors"]) == 0
            
        except Exception as e:
            results["errors"].append(f"Validation failed: {e}")
        
        return results

    def _derive_key(self, password: str, salt: bytes, context: str = "encryption") -> bytes:
        """
        Derive encryption key using Argon2 with caching
        
        Args:
            password: Password to derive from
            salt: Random salt
            context: Context for key derivation
        
        Returns:
            Derived key bytes
        """
        # Create cache key
        cache_key = SHA3_256.new(password.encode() + salt + context.encode()).hexdigest()
        
        with self._cache_lock:
            if cache_key in self._key_cache:
                return self._key_cache[cache_key]
        
        params = self.config.get_argon2_params()
        
        try:
            key = hash_secret_raw(
                secret=password.encode('utf-8'),
                salt=salt,
                hash_len=self.key_len,
                type=Type.ID,
                **params
            )
            
            # Cache the key (with size limit)
            with self._cache_lock:
                if len(self._key_cache) > 100:  # Limit cache size
                    # Remove oldest entry
                    oldest_key = next(iter(self._key_cache))
                    del self._key_cache[oldest_key]
                
                self._key_cache[cache_key] = key
            
            return key
            
        except Exception as e:
            raise DevCryptError(f"Key derivation failed: {e}")

    def _combine_factors(self, user_password: str, server_token: str) -> str:
        """
        Securely combine user password and server token with token validation
        
        Uses BLAKE2b for better mixing than simple concatenation
        """
        # Validate server token if mandatory Devanagari is enabled
        if self.config.mandatory_devanagari:
            validation = self.validate_token_format(server_token, strict=False)
            if not validation["valid"]:
                raise TokenValidationError(f"Server token validation failed: {validation['errors']}")
        
        # Use BLAKE2b for secure combination
        hasher = BLAKE2b.new(digest_bits=256)
        hasher.update(user_password.encode('utf-8'))
        hasher.update(b'\x00')  # Separator
        hasher.update(server_token.encode('utf-8'))
        
        # Return as base64 for consistent handling
        return base64.b64encode(hasher.digest()).decode('ascii')

    def _encrypt_aes_gcm(self, plaintext: bytes, key: bytes) -> bytes:
        """Encrypt using AES-GCM mode"""
        cipher = AES.new(key, AES.MODE_GCM)
        ciphertext, auth_tag = cipher.encrypt_and_digest(plaintext)
        return cipher.nonce + auth_tag + ciphertext

    def _decrypt_aes_gcm(self, data: bytes, key: bytes) -> bytes:
        """Decrypt using AES-GCM mode"""
        nonce = data[:16]
        auth_tag = data[16:32]
        ciphertext = data[32:]
        
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        try:
            plaintext = cipher.decrypt_and_verify(ciphertext, auth_tag)
            return plaintext
        except ValueError as e:
            raise AuthenticationError(f"GCM authentication failed: {e}")

    def _encrypt_aes_cbc_hmac(self, plaintext: bytes, key: bytes) -> bytes:
        """Encrypt using AES-CBC with HMAC authentication"""
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        
        # Pad plaintext
        padded_plaintext = pad(plaintext, AES.block_size)
        ciphertext = cipher.encrypt(padded_plaintext)
        
        # Generate HMAC
        hmac = HMAC.new(key, digestmod=SHA256)
        hmac.update(iv + ciphertext)
        auth_tag = hmac.digest()
        
        return iv + auth_tag + ciphertext

    def _decrypt_aes_cbc_hmac(self, data: bytes, key: bytes) -> bytes:
        """Decrypt using AES-CBC with HMAC verification"""
        iv = data[:16]
        auth_tag = data[16:48]
        ciphertext = data[48:]
        
        # Verify HMAC
        hmac = HMAC.new(key, digestmod=SHA256)
        hmac.update(iv + ciphertext)
        
        try:
            hmac.verify(auth_tag)
        except ValueError as e:
            raise AuthenticationError(f"HMAC verification failed: {e}")
        
        # Decrypt
        cipher = AES.new(key, AES.MODE_CBC, iv)
        padded_plaintext = cipher.decrypt(ciphertext)
        
        try:
            plaintext = unpad(padded_plaintext, AES.block_size)
            return plaintext
        except ValueError as e:
            raise DecryptionError(f"Padding removal failed: {e}")

    def _encrypt_chacha20(self, plaintext: bytes, key: bytes) -> bytes:
        """Encrypt using ChaCha20-Poly1305"""
        cipher = ChaCha20_Poly1305.new(key=key)
        ciphertext, auth_tag = cipher.encrypt_and_digest(plaintext)
        return cipher.nonce + auth_tag + ciphertext

    def _decrypt_chacha20(self, data: bytes, key: bytes) -> bytes:
        """Decrypt using ChaCha20-Poly1305"""
        nonce = data[:12]  # ChaCha20 uses 12-byte nonce
        auth_tag = data[12:28]
        ciphertext = data[28:]
        
        cipher = ChaCha20_Poly1305.new(key=key, nonce=nonce)
        try:
            plaintext = cipher.decrypt_and_verify(ciphertext, auth_tag)
            return plaintext
        except ValueError as e:
            raise AuthenticationError(f"ChaCha20 authentication failed: {e}")

def encrypt(self, plaintext: str, combined_secret: str, 
                metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Encrypt plaintext using combined secret
        
        Args:
            plaintext: Text to encrypt (Unicode supported)
            combined_secret: Combined password and token
            metadata: Optional metadata to include
        
        Returns:
            Base64 encoded encrypted data with metadata
        """
        if not plaintext:
            raise ValueError("Plaintext cannot be empty")
        
        if len(plaintext.encode('utf-8')) > self.config.max_data_size:
            raise ValueError(f"Data too large (max {self.config.max_data_size} bytes)")
        
        try:
            # Convert to bytes
            plaintext_bytes = plaintext.encode('utf-8')
            
            # Generate salt
            salt = get_random_bytes(self.salt_len)
            
            # Derive key
            key = self._derive_key(combined_secret, salt)
            
            # Create header with metadata
            header = {
                "version": self.VERSION,
                "mode": self.config.mode.value,
                "security_level": self.config.security_level.value,
                "timestamp": int(time.time()),
                "metadata": metadata or {}
            }
            
            header_bytes = json.dumps(header, separators=(',', ':')).encode('utf-8')
            header_len = len(header_bytes).to_bytes(4, 'big')
            
            # Encrypt based on mode
            if self.config.mode == CryptoMode.AES_GCM:
                encrypted_data = self._encrypt_aes_gcm(plaintext_bytes, key)
            elif self.config.mode == CryptoMode.AES_CBC_HMAC:
                encrypted_data = self._encrypt_aes_cbc_hmac(plaintext_bytes, key)
            elif self.config.mode == CryptoMode.CHACHA20_POLY1305:
                encrypted_data = self._encrypt_chacha20(plaintext_bytes, key)
            else:
                raise ConfigurationError(f"Unsupported encryption mode: {self.config.mode}")
            
            # Combine all components
            final_data = (
                self.MAGIC_BYTES +
                header_len +
                header_bytes +
                salt +
                encrypted_data
            )
            
            return base64.b64encode(final_data).decode('ascii')
            
        except Exception as e:
            if isinstance(e, DevCryptError):
                raise
            raise DevCryptError(f"Encryption failed: {e}")

def decrypt(self, b64_data: str, combined_secret: str) -> Tuple[str, Dict[str, Any]]:
        """
        Decrypt data using combined secret
        
        Args:
            b64_data: Base64 encoded encrypted data
            combined_secret: Combined password and token
        
        Returns:
            Tuple of (decrypted_text, metadata)
        """
        try:
            # Decode base64
            raw_data = base64.b64decode(b64_data)
            
            # Verify magic bytes
            if not raw_data.startswith(self.MAGIC_BYTES):
                raise ValueError("Invalid data format (missing magic bytes)")
            
            offset = len(self.MAGIC_BYTES)
            
            # Read header length
            header_len = int.from_bytes(raw_data[offset:offset+4], 'big')
            offset += 4
            
            # Read header
            header_bytes = raw_data[offset:offset+header_len]
            offset += header_len
            
            try:
                header = json.loads(header_bytes.decode('utf-8'))
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid header format: {e}")
            
            # Verify version compatibility
            if header.get("version") != self.VERSION:
                self.logger.warning(f"Version mismatch: {header.get('version')} vs {self.VERSION}")
            
            # Extract salt
            salt = raw_data[offset:offset+self.salt_len]
            offset += self.salt_len
            
            # Extract encrypted data
            encrypted_data = raw_data[offset:]
            
            # Derive key
            key = self._derive_key(combined_secret, salt)
            
            # Decrypt based on mode
            mode = CryptoMode(header.get("mode", "aes_gcm"))
            
            if mode == CryptoMode.AES_GCM:
                plaintext_bytes = self._decrypt_aes_gcm(encrypted_data, key)
            elif mode == CryptoMode.AES_CBC_HMAC:
                plaintext_bytes = self._decrypt_aes_cbc_hmac(encrypted_data, key)
            elif mode == CryptoMode.CHACHA20_POLY1305:
                plaintext_bytes = self._decrypt_chacha20(encrypted_data, key)
            else:
                raise ConfigurationError(f"Unsupported decryption mode: {mode}")
            
            # Convert back to string
            plaintext = plaintext_bytes.decode('utf-8')
            
            return plaintext, header.get("metadata", {})
            
        except Exception as e:
            if isinstance(e, DevCryptError):
                raise
            raise DecryptionError(f"Decryption failed: {e}")

def encrypt_file(self, input_path: str, output_path: str, 
                    combined_secret: str, chunk_size: int = 8192) -> None:
        """
        Encrypt a file with progress tracking
        
        Args:
            input_path: Path to input file
            output_path: Path to output encrypted file
            combined_secret: Combined password and token
            chunk_size: Size of chunks to process
        """
        try:
            file_size = os.path.getsize(input_path)
            
            if file_size > self.config.max_data_size:
                raise ValueError(f"File too large (max {self.config.max_data_size} bytes)")
            
            with open(input_path, 'rb') as infile:
                data = infile.read()
            
            # Add file metadata
            metadata = {
                "original_filename": os.path.basename(input_path),
                "file_size": file_size,
                "file_type": "binary"
            }
            
            # Encrypt as text (base64 encode binary data)
            b64_data = base64.b64encode(data).decode('ascii')
            encrypted = self.encrypt(b64_data, combined_secret, metadata)
            
            with open(output_path, 'w', encoding='utf-8') as outfile:
                outfile.write(encrypted)
                
        except Exception as e:
            raise DevCryptError(f"File encryption failed: {e}")

def decrypt_file(self, input_path: str, output_path: str, 
                    combined_secret: str) -> Dict[str, Any]:
        """
        Decrypt a file
        
        Args:
            input_path: Path to encrypted file
            output_path: Path to output decrypted file
            combined_secret: Combined password and token
        
        Returns:
            File metadata
        """
        try:
            with open(input_path, 'r', encoding='utf-8') as infile:
                encrypted_data = infile.read()
            
            decrypted_b64, metadata = self.decrypt(encrypted_data, combined_secret)
            
            # Decode from base64
            data = base64.b64decode(decrypted_b64)
            
            with open(output_path, 'wb') as outfile:
                outfile.write(data)
            
            return metadata
            
        except Exception as e:
            raise DevCryptError(f"File decryption failed: {e}")

def clear_key_cache(self) -> None:
        """Clear the key derivation cache"""
        with self._cache_lock:
            self._key_cache.clear()
def get_stats(self) -> Dict[str, Any]:
        """Get encryption statistics"""
        with self._cache_lock:
            cache_size = len(self._key_cache)
        
        return {
            "version": self.VERSION,
            "config": {
                "mode": self.config.mode.value,
                "security_level": self.config.security_level.value,
                "max_data_size": self.config.max_data_size
            },
            "cache_size": cache_size,
            "supported_modes": [mode.value for mode in CryptoMode],
            "supported_scripts": ["latin", "devanagari", "arabic", "cyrillic", "greek", "hebrew"]
        }


# Convenience functions with enhanced features
def encrypt(plaintext: str, user_password: str, server_token: Optional[str] = None,
           security_level: SecurityLevel = SecurityLevel.BALANCED,
           mode: CryptoMode = CryptoMode.AES_GCM,
           use_devanagari: bool = True) -> Tuple[str, str]:
    """
    High-level encryption function with modern defaults and Devanagari support
    
    Args:
        plaintext: Text to encrypt
        user_password: User password
        server_token: Optional server token (will generate if None)
        security_level: Security level
        mode: Encryption mode
        use_devanagari: Whether to include Devanagari script in token generation
    
    Returns:
        Tuple of (encrypted_data, server_token)
    
    Example:
        >>> encrypted_data, token = encrypt("Hello 世界! 🔐", "mypassword", use_devanagari=True)
        >>> print(f"Encrypted: {encrypted_data[:50]}...")
        >>> print(f"Token (with Devanagari): {token}")
    """
    config = CryptoConfig(mode=mode, security_level=security_level)
    dc = DevCrypt(config)
    
    if server_token is None:
        server_token = dc.generate_server_token(
            length=32, 
            include_devanagari=use_devanagari,
            devanagari_ratio=1.0
        )
    
    combined_secret = dc._combine_factors(user_password, server_token)
    encrypted_data = dc.encrypt(plaintext, combined_secret)
    
    return encrypted_data, server_token


def decrypt(b64_data: str, user_password: str, server_token: str) -> str:
    """
    High-level decryption function
    
    Args:
        b64_data: Base64 encoded encrypted data
        user_password: User password
        server_token: Server token (may contain Devanagari characters)
    
    Returns:
        Decrypted text
    """
    dc = DevCrypt()  # Uses default config
    combined_secret = dc._combine_factors(user_password, server_token)
    decrypted_text, _ = dc.decrypt(b64_data, combined_secret)
    
    return decrypted_text