from setuptools import setup, find_packages

setup(
    name="devcrypt",
    version="1.0.0",
    author="Atharva Panchal, Mohit Chaudhari",
    author_email="atharvapanchal95@gmail.com, mohitcha842@gmail.com",
    description="Secure Devanagari-based encryption library with Argon2 and HMAC",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pycryptodome>=3.19.1",
        "argon2-cffi>=21.3.0",
        "requests>=2.25.1"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security :: Cryptography",
    ],
    python_requires=">=3.7",
)

