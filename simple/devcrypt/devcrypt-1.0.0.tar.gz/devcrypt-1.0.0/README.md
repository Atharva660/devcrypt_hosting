# DevCrypt 🔐

DevCrypt is a modern, highly secure encryption library that uses Argon2id key derivation, AES-256 encryption (CBC mode), and HMAC-SHA256 for message integrity. It supports secure two-factor encryption using a combination of user input and a server-generated token — making it ideal for enterprise-grade use.

---

## ✨ Features

- AES-256 (CBC mode) for encryption
- Argon2id-based key derivation (resistant to GPU/ASIC cracking)
- HMAC-SHA256 for tamper detection
- Two-factor protection (User Password + Server Token)
- Secure random salt and IV generation
- Unicode (including Devanagari) safe

---

## 📦 Installation

```bash
pip install pycryptodome

## Usage

from devcrypt.core import DevCrypt

# Initialize
dev = DevCrypt()

# 1. Generate server token (should be stored securely on server side)
server_token = dev.generate_server_token()

# 2. Combine user password + server token
user_password = "MySecureP@ss123"
combined_key = dev.combine_factors(user_password, server_token)

# 3. Encrypt
message = "नमस्ते, यह एक एन्क्रिप्टेड संदेश है।"
encrypted = dev.encrypt(message, combined_key)
print("Encrypted:", encrypted)

# 4. Decrypt
decrypted = dev.decrypt(encrypted, combined_key)
print("Decrypted:", decrypted)


