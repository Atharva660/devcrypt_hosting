import os
import base64
import string
import secrets
from Crypto.Cipher import AES
from Crypto.Hash import HMAC, SHA256
from argon2.low_level import hash_secret_raw, Type
from Crypto.Util.Padding import pad, unpad

class DevCrypt:
    def __init__(self):
        self.salt_len = 16
        self.iv_len = 16
        self.key_len = 32

    def generate_server_token(self, length=32):
        """Generate a secure random server token"""
        chars = string.ascii_letters + string.digits + "!@#$%^&*()-_+="
        return ''.join(secrets.choice(chars) for _ in range(length))

    def derive_key(self, password: str, salt: bytes):
        """Derive encryption key using Argon2"""
        return hash_secret_raw(
            secret=password.encode(),
            salt=salt,
            time_cost=3,
            memory_cost=65536,
            parallelism=1,
            hash_len=self.key_len,
            type=Type.ID
        )

    def combine_factors(self, user_password: str, server_token: str) -> str:
        """Combine user password and server token"""
        return user_password + server_token

    def encrypt(self, plaintext: str, combined_secret: str):
        """Encrypt plaintext using combined secret"""
        salt = os.urandom(self.salt_len)
        iv = os.urandom(self.iv_len)
        key = self.derive_key(combined_secret, salt)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        ciphertext = cipher.encrypt(pad(plaintext.encode('utf-8'), AES.block_size))
        hmac = HMAC.new(key, digestmod=SHA256)
        hmac.update(salt + iv + ciphertext)
        return base64.b64encode(salt + iv + ciphertext + hmac.digest()).decode()

    def decrypt(self, b64_data: str, combined_secret: str):
        """Decrypt data using combined secret"""
        raw = base64.b64decode(b64_data)
        salt = raw[:self.salt_len]
        iv = raw[self.salt_len:self.salt_len + self.iv_len]
        ciphertext = raw[self.salt_len + self.iv_len:-32]
        hmac_received = raw[-32:]
        key = self.derive_key(combined_secret, salt)
        hmac = HMAC.new(key, digestmod=SHA256)
        hmac.update(salt + iv + ciphertext)
        hmac.verify(hmac_received)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        plaintext = unpad(cipher.decrypt(ciphertext), AES.block_size)
        return plaintext.decode('utf-8')


# Convenience functions for direct import
def encrypt(plaintext: str, user_password: str, server_token: str = None):
    """
    Encrypt plaintext using user password and optional server token.
    
    Args:
        plaintext (str): Text to encrypt
        user_password (str): User's password
        server_token (str, optional): Server token (will generate if None)
    
    Returns:
        tuple: (encrypted_data, server_token)
    
    Example:
        >>> encrypted_data, token = encrypt("Hello World", "mypassword")
        >>> print(f"Encrypted: {encrypted_data}")
        >>> print(f"Token: {token}")
    """
    dc = DevCrypt()
    if server_token is None:
        server_token = dc.generate_server_token()
    combined_secret = dc.combine_factors(user_password, server_token)
    encrypted_data = dc.encrypt(plaintext, combined_secret)
    return encrypted_data, server_token

def decrypt(b64_data: str, user_password: str, server_token: str):
    """
    Decrypt data using user password and server token.
    
    Args:
        b64_data (str): Base64 encoded encrypted data
        user_password (str): User's password
        server_token (str): Server token used during encryption
    
    Returns:
        str: Decrypted plaintext
    
    Example:
        >>> decrypted_text = decrypt(encrypted_data, "mypassword", token)
        >>> print(f"Decrypted: {decrypted_text}")
    
    Raises:
        ValueError: If HMAC verification fails
        UnicodeDecodeError: If decrypted data is not valid UTF-8
    """
    dc = DevCrypt()
    combined_secret = dc.combine_factors(user_password, server_token)
    return dc.decrypt(b64_data, combined_secret)