# __init__.py
"""
DevCrypt - Secure Devanagari-based encryption library with Argon2 and HMAC
"""

__version__ = "1.0.0"
__author__ = "Atharva Panchal, Mohit Chaudhari"
__email__ = "atharvapanchal95@gmail.com, mohitcha842@gmail.com"

from .core import (
    DevCrypt,
    DevCryptError,
    DecryptionError,
    AuthenticationError,
    ConfigurationError,
    CryptoConfig,
    CryptoMode,
    SecurityLevel,
    encrypt,
    decrypt
)

__all__ = [
    "DevCrypt",
    "DevCryptError",
    "DecryptionError",
    "AuthenticationError",
    "ConfigurationError",
    "CryptoConfig",
    "CryptoMode",
    "SecurityLevel",
    "encrypt",
    "decrypt"
]
